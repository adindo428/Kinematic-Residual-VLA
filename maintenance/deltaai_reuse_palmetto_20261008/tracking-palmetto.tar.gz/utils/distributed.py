# -*- coding: utf-8 -*-
#
# @File:   distributed.py
# @Author: NVIDIA
# @Date:   2023-04-29 11:50:12
# @Last Modified by: Haozhe Xie
# @Last Modified at: 2025-08-30 19:59:11
# @Email:  root@haozhexie.com
# @Ref: https://github.com/NVlabs/imaginaire

import ctypes
import logging
import math
import os

import pynvml
import torch
import torch.distributed

_nvml_initialized = False


def _ensure_nvml_initialized():
    global _nvml_initialized
    if not _nvml_initialized:
        pynvml.nvmlInit()
        _nvml_initialized = True


class Device(object):
    r"""Device used for nvml."""

    _nvml_affinity_elements = math.ceil(os.cpu_count() / 64)

    def __init__(self, device_idx):
        super().__init__()
        _ensure_nvml_initialized()
        self.handle = pynvml.nvmlDeviceGetHandleByIndex(device_idx)

    def getName(self):
        r"""Get obect name"""
        return pynvml.nvmlDeviceGetName(self.handle)

    def getCpuAffinity(self):
        r"""Get CPU affinity"""
        affinity_string = ""
        for j in pynvml.nvmlDeviceGetCpuAffinity(
            self.handle, Device._nvml_affinity_elements
        ):
            # assume nvml returns list of 64 bit ints
            affinity_string = "{:064b}".format(j) + affinity_string
        affinity_list = [int(x) for x in affinity_string]
        affinity_list.reverse()  # so core 0 is in 0th element of list

        return [i for i, e in enumerate(affinity_list) if e != 0]


def set_affinity(gpu_id=None):
    r"""Set GPU affinity
    Args:
        gpu_id (int): Which gpu device.
    """
    if gpu_id is None:
        gpu_id = int(os.getenv("LOCAL_RANK", 0))

    dev = Device(gpu_id)
    current_affinity = os.sched_getaffinity(0)
    device_affinity = set(dev.getCpuAffinity())
    target_affinity = sorted(device_affinity & current_affinity)

    if not target_affinity:
        logging.warning(
            "Skipping GPU CPU affinity for GPU %s: NVML CPUs %s do not overlap "
            "the process CPU set %s.",
            gpu_id,
            sorted(device_affinity),
            sorted(current_affinity),
        )
        return current_affinity

    try:
        os.sched_setaffinity(0, target_affinity)
    except OSError as exc:
        logging.warning(
            "Failed to set GPU CPU affinity for GPU %s to %s; keeping CPU set %s: %s",
            gpu_id,
            target_affinity,
            sorted(current_affinity),
            exc,
        )
        return current_affinity

    # list of ints
    # representing the logical cores this process is now affinitied with
    return os.sched_getaffinity(0)


def init_dist(local_rank, backend="nccl", **kwargs):
    r"""Initialize distributed training"""
    if torch.distributed.is_available():
        if torch.distributed.is_initialized():
            return torch.cuda.current_device()

        torch.cuda.set_device(local_rank)
        torch.distributed.init_process_group(
            backend=backend, init_method="env://", **kwargs
        )

    # Increase the L2 fetch granularity for faster speed.
    _libcudart = ctypes.CDLL("libcudart.so")
    # Set device limit on the current device
    # cudaLimitMaxL2FetchGranularity = 0x05
    pValue = ctypes.cast((ctypes.c_int * 1)(), ctypes.POINTER(ctypes.c_int))
    _libcudart.cudaDeviceSetLimit(ctypes.c_int(0x05), ctypes.c_int(128))
    _libcudart.cudaDeviceGetLimit(pValue, ctypes.c_int(0x05))
    # assert pValue.contents.value == 128


def launched_with_torchrun():
    return all(k in os.environ for k in ("RANK", "WORLD_SIZE", "LOCAL_RANK"))


def is_initialized():
    return torch.distributed.is_available() and torch.distributed.is_initialized()


def cleanup_dist():
    # Fix: process group has NOT been destroyed before we destruct ProcessGroupNCCL.
    if is_initialized():
        torch.distributed.destroy_process_group()


def get_rank():
    r"""Get rank of the thread."""
    rank = 0
    if is_initialized():
        rank = torch.distributed.get_rank()

    return rank


def get_local_rank():
    r"""Get local rank of the thread."""
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    return local_rank


def get_world_size():
    r"""Get world size. How many GPUs are available in this job."""
    world_size = 1
    if is_initialized():
        world_size = torch.distributed.get_world_size()

    return world_size


def is_master():
    r"""check if current process is the master"""
    return get_rank() == 0


def is_local_master():
    if is_initialized():
        return get_local_rank() == 0
    return True
