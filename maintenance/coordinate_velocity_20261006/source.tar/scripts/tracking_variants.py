"""Stable tracking methods; DOM+Velocity uses neural conditioning without analytic drift."""
VARIANT_LABELS = {'baseline': 'DOM-VLA', 'velocity': 'DOM-VLA+Velocity',
                  'residual': 'KR-VLA-Field', 'coordinate': 'KR-VLA-Coordinate'}

def checkpoints_from_args(args):
    result = {'baseline': args.baseline}
    if getattr(args, 'velocity', None): result['velocity'] = args.velocity
    result['residual'] = args.residual
    if getattr(args, 'coordinate', None): result['coordinate'] = args.coordinate
    return result

def validate_variant(config, variant):
    if variant not in VARIANT_LABELS: raise ValueError(f'Unknown variant {variant}')
    if bool(config.enable_residual_flow) != (variant in ('residual','coordinate')):
        raise ValueError(f'{variant}: checkpoint residual enable flag differs')
    if bool(getattr(config,'condition_on_object_velocity',False)) != (variant == 'velocity'):
        raise ValueError(f'{variant}: checkpoint velocity conditioning flag differs')
    expected = 'coordinate' if variant == 'coordinate' else 'field'
    actual = getattr(config, 'residual_flow_formulation', 'field')
    if variant in ('residual','coordinate') and actual != expected:
        raise ValueError(f'{variant}: expected {expected} formulation, got {actual}')
